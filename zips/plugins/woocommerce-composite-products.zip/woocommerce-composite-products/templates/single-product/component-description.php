<?php
/**
 * Component Description Template.
 *
 * @version  3.0.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<p class="component_description"><?php
	echo $description;
?></p>
