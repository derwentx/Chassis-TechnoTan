<?php

add_filter( 'wc_gateway_paypal_express_skip_line_items', '__return_true' );

