=== WooCommerce Memberships ===
Author: woothemes, skyverge
Tags: woocommerce
Requires at least: 3.8
Tested up to: 4.2.3
Requires WooCommerce at least: 2.2
Tested WooCommerce up to: 2.4

See http://docs.woothemes.com/document/woocommerce-memberships/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-memberships' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
