WooCommerce Product Details Customiser
======================================

Allows you to customise WooCommerce product details pages. Show / Hide core components like product imagery, tabs, upsells and related products.